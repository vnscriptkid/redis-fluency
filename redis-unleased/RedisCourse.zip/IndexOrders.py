from redis_om import Migrator
from Schema import *

Migrator().run()
